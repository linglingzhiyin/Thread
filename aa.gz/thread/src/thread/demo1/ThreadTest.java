package thread.demo1;

public class ThreadTest {

    public static void main(String[] args) {
        ThreadRunnable threadRunnable = new ThreadRunnable();
        Thread t1 = new Thread(threadRunnable, "t1");
        Thread t2 = new Thread(threadRunnable, "t2");
        t1.setDaemon(true);
        t1.start();
//        t2.start();
        try {
            Thread.sleep(20_000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("main end");

    }
}
