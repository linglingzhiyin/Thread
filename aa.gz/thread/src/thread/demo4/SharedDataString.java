package thread.demo4;

public class SharedDataString {

    private String buffer;

    private ReadWriteLock lock = new ReadWriteLock();

    public SharedDataString(String buffer) {
        this.buffer = buffer;
    }

    //读操作
    public String read() throws InterruptedException {
        try {
            lock.readLock();
            return this.buffer;
        } finally {
            slowly(1150);
            lock.readUnlock();
        }
    }


    //写操作
    public void write(String  st) throws InterruptedException {
        try {
            lock.writeLock();
            this.buffer=st;
        } finally {
            slowly(10);
            lock.writeUnlock();
        }
    }

    private void slowly(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


}
