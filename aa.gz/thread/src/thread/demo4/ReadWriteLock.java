package thread.demo4;


/**
 * 读写锁分离
 * <p>
 * read read     并行
 * read write    不允许
 * write write   不允许
 */
public class ReadWriteLock {
    //多少个线程进行读的操作
    private int readingReaders = 0;
    //多少个线程等待读的操作
    private int waitingReaders = 0;
    //多少个线程进行写的操作 只有一个
    private int writingWriters = 0;
    //多少个线程等待写的操作
    private int waitingWriters = 0;

    private boolean preferWrite=true;

    public ReadWriteLock() {
        this(true);
    }

    public ReadWriteLock(boolean preferWrite) {
        this.preferWrite = preferWrite;
    }

    public synchronized void readLock() throws InterruptedException {
        //当前线程进行读 等待读+1
        this.waitingReaders++;
        try {
            //判断是否有线程在写，有就等待，没有就读
            while (writingWriters > 0||(preferWrite&&waitingWriters>0)) {
                this.wait();
            }
            //进行读
            this.readingReaders++;
        } finally {
            //读完了，waitingReaders-1；
            this.waitingReaders--;
        }
    }

    public synchronized void readUnlock() {
        this.readingReaders--;
        this.notifyAll();
    }

    public synchronized void writeLock() throws InterruptedException {
        //当前线程进行写 等待写+1
        this.waitingWriters++;
        try {
            //判断是否有线程在读或者有线程在写，有就等待
            while (readingReaders > 0 || writingWriters > 0) {
                this.wait();
            }
            //进行写
            this.writingWriters++;
        } finally {
            //写完了，waitingReaders-1；
            this.waitingWriters--;
        }
    }

    public synchronized void writeUnlock() {
        this.writingWriters--;
        this.notifyAll();
    }

}
