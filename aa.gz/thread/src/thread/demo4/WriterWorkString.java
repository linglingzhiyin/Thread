package thread.demo4;

import java.util.Random;

public class WriterWorkString extends Thread {

    private static final Random random = new Random(System.currentTimeMillis());
    private SharedDataString dataString;
    private String filler;

    public WriterWorkString(SharedDataString dataString, String filler) {
        this.dataString = dataString;
        this.filler = filler;
    }

    @Override
    public void run() {
        try {
            System.out.println(Thread.currentThread().getName()+"fsdfsafasf");
            dataString.write(filler);
            Thread.sleep(10_000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
