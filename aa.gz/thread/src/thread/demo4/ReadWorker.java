package thread.demo4;

public class ReadWorker extends Thread {

    private SharedData data;

    private SharedDataString dataString;

    public ReadWorker(SharedData data) {
        this.data = data;
    }

    public ReadWorker(SharedDataString dataString) {
        this.dataString = dataString;
    }

    @Override
    public void run() {
        try {
            while (true) {
                char[] readBuf = data.read();
                System.out.println(Thread.currentThread().getName() + "reads" + String.valueOf(readBuf));
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
