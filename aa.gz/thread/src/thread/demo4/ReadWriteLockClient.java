package thread.demo4;


/**
 * ReadWriteLock 设计模式
 * Reader-Worker 设计模式
 */
public class ReadWriteLockClient {
    public static void main(String[] args) throws InterruptedException {
        final SharedData data = new SharedData(10);
        final SharedDataString dataString = new SharedDataString("abcabc");

/*        new ReadWorker(data).start();
        new ReadWorker(data).start();
        new ReadWorker(data).start();
        new ReadWorker(data).start();
        new ReadWorker(data).start();
        new ReadWorker(data).start();
        new ReadWorker(data).start();
        new WriterWork(data, "oqweqwew").start();
        new WriterWork(data, "OQWEQWEW").start();*/
        /**
         *  多线程
         *  字符串的读写分离
         * */
        new ReadWorkerString(dataString).start();
        new ReadWorkerString(dataString).start();
        WriterWorkString oqweqwew = new WriterWorkString(dataString, "oqweqwew");
        oqweqwew.start();
        oqweqwew.join();
        new WriterWorkString(dataString, "OQWEQWEW").start();

    }

}
