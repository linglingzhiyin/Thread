package thread.demo4;

public class ReadWorkerString extends Thread {

    private SharedDataString dataString;

    public ReadWorkerString(SharedDataString dataString) {
        this.dataString = dataString;
    }

    @Override
    public void run() {
        try {
            while (true) {
                String readBuf = dataString.read();
                System.out.println(Thread.currentThread().getName() + "reads:" + readBuf);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
