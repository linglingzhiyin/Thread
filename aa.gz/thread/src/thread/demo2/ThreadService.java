package thread.demo2;

public class ThreadService {


    private Thread executeTread;

    private boolean finshed = false;

    public void execute(Runnable task) {
        executeTread = new Thread() {
            @Override
            public void run() {
                Thread runner = new Thread(task);
                runner.setDaemon(true);
                runner.start();
                try {
                    runner.join();
                    finshed = true;
                } catch (InterruptedException e) {
                    //e.printStackTrace();
                }
            }
        };

    }

    public void shutdown(long mills) {
        long currenTime = System.currentTimeMillis();
        while (!finshed){
            if ((System.currentTimeMillis()-currenTime)>mills){
                System.out.println("out time");
                executeTread.interrupt();
                break;
            }
            try {
                executeTread.sleep(1);
            } catch (InterruptedException e) {
                System.out.println("执行线程被打短");
                break;
            }
        }
        finshed=false;


    }
}
