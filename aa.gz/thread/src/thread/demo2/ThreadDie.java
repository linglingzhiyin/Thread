package thread.demo2;

public class ThreadDie {
    public static void main(String[] args) {

        new Thread().stop();

        ThreadService service=new ThreadService();
        service.execute(()->{
            while (true){

            }
        });
        try {
            Thread.sleep(10_000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        service.shutdown(10);
    }
}
