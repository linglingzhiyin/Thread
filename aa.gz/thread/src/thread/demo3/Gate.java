package thread.demo3;

//
public class Gate {
    private int counter = 0;
    private String name = "nobody";
    private String address = "Nowhere";
    private Object LOCK = new Object();

    /**
     * @param name
     * @param address
     */
    public void pass(String name, String address) {
        synchronized (LOCK) {
            this.counter++;
            this.name = name;
            this.address = address;
            verify();
        }
    }

    private void verify() {

        if (this.name.charAt(0) != this.address.charAt(0)) {
            System.out.println("***********BROKEN**********" + toString());
        }

    }

    @Override
    public String toString() {
        return "NO." + counter + ":" + name + "," + address;
    }
}
