package thread.demo3;

public class Client {


    public static void main(String[] args) {
        Gate gate = new Gate();
        User bj = new User("BaoBao", "Beijing", gate);
        User sh = new User("ShangLao", "ShangHai", gate);
        User gz = new User("GuangLao", "GuangDong", gate);
        User bj1 = new User("BaoBao", "Beijing", gate);
        User sh1 = new User("ShangLao", "ShangHai", gate);
        User gz1 = new User("GuangLao", "GuangDong", gate);
        bj.start();
        sh.start();
        gz.start();
        bj1.start();
        sh1.start();
        gz1.start();
    }
}
